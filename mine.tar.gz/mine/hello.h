#include <stdio.h>

int	sum(int first, int second);
int	minus(int first, int second);


#include "hello.h"

int	sum(int first, int second)
{
	return first + second;
}

int	minus(int first, int second)
{
	return first - second;
}
